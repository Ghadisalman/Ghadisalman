package com.project.ehyaa;

import android.app.AlertDialog;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.CompoundButton;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import com.creageek.segmentedbutton.SegmentedButton;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;

public class SignupActivity extends AppCompatActivity {

    private TextView textView;
    private RadioButton patient;
    private RadioButton donor;
    private RadioButton hospital;
    private SegmentedButton options;
    private EditText fullname;
    private EditText hospitalName;
    private Spinner city;
    private EditText email;
    private EditText phone;
    private EditText national;
    private EditText DateofBirth;
    private Spinner bloodType;
    private EditText Password;
    private EditText ConfirmPassword;
    private Button sign_up;
    private FirebaseAuth mAuth;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_signup);
        textView = findViewById(R.id.textView);
        patient = findViewById(R.id.patient);
        donor = findViewById(R.id.donor);
        hospital = findViewById(R.id.hospital);
        options = findViewById(R.id.options);
        fullname = findViewById(R.id.fullname);
        hospitalName = findViewById(R.id.hospital_name);
        city = findViewById(R.id.city);
        email = findViewById(R.id.email);
        phone = findViewById(R.id.phone);
        national = findViewById(R.id.national);
        DateofBirth = findViewById(R.id.DateofBirth);
        bloodType = findViewById(R.id.bloodType);
        Password = findViewById(R.id.Password);
        ConfirmPassword = findViewById(R.id.ConfirmPassword);
        sign_up = findViewById(R.id.sign_up);
        mAuth = FirebaseAuth.getInstance();

        patient.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                if(isChecked) {
                    fullname.setVisibility(View.VISIBLE);
                    hospitalName.setVisibility(View.GONE);
                    city.setVisibility(View.GONE);
                    email.setVisibility(View.VISIBLE);
                    phone.setVisibility(View.VISIBLE);
                    national.setVisibility(View.VISIBLE);
                    DateofBirth.setVisibility(View.VISIBLE);
                    bloodType.setVisibility(View.VISIBLE);
                }


            }
        });

        donor.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                if(isChecked) {
                    fullname.setVisibility(View.VISIBLE);
                    hospitalName.setVisibility(View.GONE);
                    city.setVisibility(View.GONE);
                    email.setVisibility(View.VISIBLE);
                    phone.setVisibility(View.VISIBLE);
                    national.setVisibility(View.VISIBLE);
                    DateofBirth.setVisibility(View.VISIBLE);
                    bloodType.setVisibility(View.VISIBLE);
                }
            }
        });

        hospital.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                if(isChecked) {
                    fullname.setVisibility(View.GONE);
                    hospitalName.setVisibility(View.VISIBLE);
                    city.setVisibility(View.VISIBLE);
                    email.setVisibility(View.VISIBLE);
                    phone.setVisibility(View.VISIBLE);
                    national.setVisibility(View.GONE);
                    DateofBirth.setVisibility(View.GONE);
                    bloodType.setVisibility(View.GONE);
                }
            }
        });

        sign_up.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                mAuth.createUserWithEmailAndPassword(email.getText().toString(), Password.getText().toString())
                        .addOnCompleteListener(SignupActivity.this, new OnCompleteListener<AuthResult>() {
                            @Override
                            public void onComplete(@NonNull Task<AuthResult> task) {
                                if (task.isSuccessful()) {
                                    // Sign in success, update UI with the signed-in user's information
                                  //  Toast.makeText(SignupActivity.this, "User Register Successfully", Toast.LENGTH_SHORT).show();
                                    new AlertDialog.Builder(SignupActivity.this).setMessage("User Register Successfully").show();

                                } else {
                                    // If sign in fails, display a message to the user.
                                    new AlertDialog.Builder(SignupActivity.this).setMessage(task.getException().getMessage()).show();
                                }
                            }
                        });
            }
        });
    }
}