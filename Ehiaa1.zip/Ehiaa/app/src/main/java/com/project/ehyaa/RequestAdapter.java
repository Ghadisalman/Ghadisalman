package com.project.ehyaa;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.net.Uri;
import android.preference.PreferenceManager;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageReference;

import java.io.Serializable;
import java.util.ArrayList;

public class RequestAdapter extends RecyclerView.Adapter<RequestAdapter.RequestViewHolder> {

    Context context;
    ArrayList<Request> requests;
    String userCat;
    public RequestAdapter(Context context, ArrayList<Request> requests) {
        this.context = context;
        this.requests = requests;
        SharedPreferences sharedPreferences = PreferenceManager.getDefaultSharedPreferences(context);

         userCat =  sharedPreferences.getString("userCat","");
    }

    @NonNull
    @Override
    public RequestViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(context).inflate(R.layout.request,parent,false);
        return new RequestViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull RequestViewHolder holder, int position) {
        FirebaseDatabase.getInstance().getReference("users").child(requests.get(position).getPatientId()).get().addOnCompleteListener(new OnCompleteListener<DataSnapshot>() {
            @Override
            public void onComplete(@NonNull Task<DataSnapshot> task) {
                if(task.isSuccessful()){
                    User user = task.getResult().getValue(User.class);
                    if (userCat.equals("hospital")){
                        FirebaseDatabase.getInstance().getReference("users").child(requests.get(position).getHospitalId()).get().addOnCompleteListener(new OnCompleteListener<DataSnapshot>() {
                            @Override
                            public void onComplete(@NonNull Task<DataSnapshot> task) {
                                User hospital = task.getResult().getValue(User.class);
                                holder.name.setText(hospital.hospitalName);
                            }
                        });
                    }else {
                        holder.name.setText(user.fullname.isEmpty()? user.hospitalName:user.fullname);
                    }


                    if(requests.get(position).getHospitalId().equals(requests.get(position).getPatientId())){
                        holder.data.setText(requests.get(position).getRequestType()+" - " + requests.get(position).getBloodType());

                    }else{
                        holder.data.setText(requests.get(position).getRequestType()+" - " + (requests.get(position).getRequestType().equals("Blood")? requests.get(position).getBloodType()+"" : user.bloodType+""));

                    }
                    StorageReference storageRef = FirebaseStorage.getInstance().getReference().child("UsersImages").child(requests.get(position).getPatientId()+".jpeg");
                    storageRef.getDownloadUrl().addOnSuccessListener(new OnSuccessListener<Uri>() {
                        @Override
                        public void onSuccess(Uri uri) {
                            // Got the download URL for 'users/me/profile.png'
                            Glide.with(context)
                                    .load(uri)
                                    .placeholder(R.drawable.u)
                                    .into(holder.image);
                        }
                    }).addOnFailureListener(new OnFailureListener() {
                        @Override
                        public void onFailure(@NonNull Exception exception) {
                            // Handle any errors
                        }
                    });
                }
            }
        });



    }

    @Override
    public int getItemCount() {
        return requests.size();
    }

    class RequestViewHolder extends RecyclerView.ViewHolder{
        TextView name,data;
        ImageView image;
        public RequestViewHolder(@NonNull View itemView) {
            super(itemView);

            name = itemView.findViewById(R.id.name);
            image = itemView.findViewById(R.id.image);
            data = itemView.findViewById(R.id.data);
            itemView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    Intent intent = new Intent(context,ShowRequestDetailsActivity.class);
                    intent.putExtra("request", requests.get(getAdapterPosition()));
                    context.startActivity(intent);
                }
            });
        }
    }

}
