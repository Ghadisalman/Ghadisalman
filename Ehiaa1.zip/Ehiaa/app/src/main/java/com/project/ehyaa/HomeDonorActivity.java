package com.project.ehyaa;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentTransaction;

import android.os.Bundle;
import android.view.MenuItem;

import com.google.android.material.bottomnavigation.BottomNavigationView;
import com.google.android.material.navigation.NavigationBarView;

public class HomeDonorActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home_donor);
        getSupportActionBar().setTitle("Home");
        getSupportFragmentManager().beginTransaction().replace(R.id.flFragment,new RequstsFragment()).commit();
        BottomNavigationView bottomNavigationView = findViewById(R.id.bottomNavigationView);
        bottomNavigationView.setOnItemSelectedListener(new NavigationBarView.OnItemSelectedListener() {
            @Override
            public boolean onNavigationItemSelected(@NonNull MenuItem item) {
                Fragment fragment = null;
                FragmentTransaction transaction = getSupportFragmentManager().beginTransaction();
                if(item.getItemId() == R.id.home){
                    getSupportActionBar().setTitle("Home");
                    fragment =  new RequstsFragment();
                }else if(item.getItemId() == R.id.notification){
                    getSupportActionBar().setTitle("Notification");
                    fragment =  new NotificationFragment();
                }else if(item.getItemId() == R.id.chat){
                    getSupportActionBar().setTitle("Chat");
                    fragment =  new ChatFragment();
                }else if(item.getItemId() == R.id.profile){
                    getSupportActionBar().setTitle("Profile");
                    fragment =  new ProfilePatientFragment();
                }
                transaction.replace(R.id.flFragment,fragment).commit();
                return true;
            }
        });
    }
}