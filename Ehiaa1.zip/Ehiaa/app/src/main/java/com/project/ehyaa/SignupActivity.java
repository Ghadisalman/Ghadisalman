package com.project.ehyaa;

import android.app.AlertDialog;
import android.app.DatePickerDialog;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.preference.PreferenceManager;
import android.util.Patterns;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.CompoundButton;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.ProgressBar;
import android.widget.RadioButton;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import com.creageek.segmentedbutton.SegmentedButton;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

import java.util.Calendar;

public class SignupActivity extends AppCompatActivity {
    User user;
    private TextView textView;
    private RadioButton patient;
    private RadioButton donor;
    private RadioButton hospital;
    private SegmentedButton options;
    private EditText fullname;
    private EditText hospitalName;
    private Spinner city;
    private EditText email;
    private EditText phone;
    private EditText national;
    private EditText DateofBirth;
    private ProgressBar progressBar;
    private Spinner bloodType;
    private EditText Password;
    private EditText ConfirmPassword;
    private Button sign_up;
    private FirebaseAuth mAuth;
    private String userCat = "patient";
    private DatabaseReference mDatabase;

    SharedPreferences sharedPreferences;
    SharedPreferences.Editor editor;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_signup);
        textView = findViewById(R.id.textView);
        patient = findViewById(R.id.patient);
        donor = findViewById(R.id.donor);
        hospital = findViewById(R.id.hospital);
        options = findViewById(R.id.options);
        progressBar = findViewById(R.id.progressBar);
        fullname = findViewById(R.id.fullname);
        hospitalName = findViewById(R.id.hospital_name);
        city = findViewById(R.id.city);
        email = findViewById(R.id.email);
        phone = findViewById(R.id.phone);
        national = findViewById(R.id.national);
        DateofBirth = findViewById(R.id.DateofBirth);
        bloodType = findViewById(R.id.bloodType);
        Password = findViewById(R.id.Password);
        ConfirmPassword = findViewById(R.id.ConfirmPassword);
        sign_up = findViewById(R.id.sign_up);
        mAuth = FirebaseAuth.getInstance();
        DateofBirth.setOnFocusChangeListener(new View.OnFocusChangeListener() {
            @Override
            public void onFocusChange(View v, boolean hasFocus) {
                if(hasFocus){
                    final Calendar c = Calendar.getInstance();
                    int year = c.get(Calendar.YEAR);
                    int month = c.get(Calendar.MONTH);
                    int day = c.get(Calendar.DAY_OF_MONTH);
                    DatePickerDialog datePickerDialog = new DatePickerDialog(SignupActivity.this, new DatePickerDialog.OnDateSetListener() {
                        @Override
                        public void onDateSet(DatePicker view, int year, int month, int dayOfMonth) {
                            DateofBirth.setText(year+"/"+month + "/" + dayOfMonth);
                        }
                    },year,month,day);
                    datePickerDialog.show();
                }
            }
        });

        sharedPreferences = PreferenceManager.getDefaultSharedPreferences(this);
        editor = sharedPreferences.edit();
        mDatabase = FirebaseDatabase.getInstance().getReference();
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        patient.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                if(isChecked) {
                    fullname.setVisibility(View.VISIBLE);
                    hospitalName.setVisibility(View.GONE);
                    city.setVisibility(View.GONE);
                    email.setVisibility(View.VISIBLE);
                    phone.setVisibility(View.VISIBLE);
                    national.setVisibility(View.VISIBLE);
                    DateofBirth.setVisibility(View.VISIBLE);
                    bloodType.setVisibility(View.VISIBLE);
                    userCat = "patient";
                }


            }
        });

        donor.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                if(isChecked) {
                    fullname.setVisibility(View.VISIBLE);
                    hospitalName.setVisibility(View.GONE);
                    city.setVisibility(View.GONE);
                    email.setVisibility(View.VISIBLE);
                    phone.setVisibility(View.VISIBLE);
                    national.setVisibility(View.VISIBLE);
                    DateofBirth.setVisibility(View.VISIBLE);
                    bloodType.setVisibility(View.VISIBLE);
                    userCat = "donor";
                }
            }
        });

        hospital.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                if(isChecked) {
                    hospitalName.setVisibility(View.VISIBLE);
                    city.setVisibility(View.VISIBLE);
                    email.setVisibility(View.VISIBLE);
                    phone.setVisibility(View.VISIBLE);
                    fullname.setVisibility(View.GONE);
                    national.setVisibility(View.GONE);
                    DateofBirth.setVisibility(View.GONE);
                    bloodType.setVisibility(View.GONE);
                    userCat = "hospital";
                }
            }
        });

        sign_up.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(!userCat.equals("hospital")) {
                    if (fullname.getText().toString().isEmpty()) {
                        fullname.setError("Enter Fullname");
                        return;
                    }

                    if(national.getText().toString().isEmpty()){
                        national.setError("Enter national");
                        return;
                    }
                    if(DateofBirth.getText().toString().isEmpty()){
                        DateofBirth.setError("Enter DateofBirth");
                        return;
                    }

                    if(bloodType.getSelectedItem().toString().equals("Select Blood Type")){
                        Toast.makeText(SignupActivity.this, "Select Blood Type", Toast.LENGTH_SHORT).show();
                        return;
                    }
                }

                if(email.getText().toString().isEmpty()){
                    email.setError("Enter email");
                    return;
                }

                if(!Patterns.EMAIL_ADDRESS.matcher(email.getText()).matches()){
                    email.setError("Enter valid email");
                    return;
                }
                
                if(phone.getText().toString().isEmpty()){
                    phone.setError("Enter phone");
                    return;
                }



                if(!phone.getText().toString().startsWith("05")){
                    phone.setError("Enter phone starts with 05");
                    return;
                }

                


                if(userCat.equals("hospital")) {
                    if (hospitalName.getText().toString().isEmpty()) {
                        hospitalName.setError("Enter hospitalName");
                        return;
                    }
                    if (city.getSelectedItem().toString().equals("Select City")) {
                        Toast.makeText(SignupActivity.this, "Select City", Toast.LENGTH_SHORT).show();
                        return;
                    }
                }
                if(Password.getText().toString().isEmpty()){
                    Password.setError("Enter Password");
                    return;
                }
                
                if(ConfirmPassword.getText().toString().isEmpty()){
                    ConfirmPassword.setError("Enter ConfirmPassword");
                    return;
                }
                if(!ConfirmPassword.getText().toString().equals(Password.getText().toString())){
                    ConfirmPassword.setError("Password not match");
                    Password.setError("Password not match");
                    return;
                }
                progressBar.setVisibility(View.VISIBLE);
                mAuth.createUserWithEmailAndPassword(email.getText().toString(), Password.getText().toString())
                        .addOnCompleteListener(SignupActivity.this, new OnCompleteListener<AuthResult>() {
                            @Override
                            public void onComplete(@NonNull Task<AuthResult> task) {
                                if (task.isSuccessful()) {
                                    // Sign in success, update UI with the signed-in user's information
                                  //  Toast.makeText(SignupActivity.this, "User Register Successfully", Toast.LENGTH_SHORT).show();
                                    if(!userCat.equals("hospital")) {
                                         user = new User(mAuth.getCurrentUser().getUid(),userCat,fullname.getText().toString(),email.getText().toString(),phone.getText().toString(),national.getText().toString(),DateofBirth.getText().toString(),bloodType.getSelectedItem().toString());
                                        mDatabase.child("users").child(mAuth.getCurrentUser().getUid()).setValue(user).addOnCompleteListener(new OnCompleteListener<Void>() {
                                            @Override
                                            public void onComplete(@NonNull Task<Void> task) {
                                                progressBar.setVisibility(View.GONE);
                                                if(task.isSuccessful()){
                                                    Toast.makeText(SignupActivity.this, "Register Successfully", Toast.LENGTH_SHORT).show();
//                                                    finish();
                                                }else{
                                                    new AlertDialog.Builder(SignupActivity.this).setMessage(task.getException().getMessage()).show();
                                                }
                                            }
                                        });
                                    }else{
                                         user = new User(mAuth.getCurrentUser().getUid(),userCat,hospitalName.getText().toString(),city.getSelectedItem().toString(),email.getText().toString(),phone.getText().toString());
                                        mDatabase.child("users").child(mAuth.getCurrentUser().getUid()).setValue(user).addOnCompleteListener(new OnCompleteListener<Void>() {
                                            @Override
                                            public void onComplete(@NonNull Task<Void> task) {
                                                progressBar.setVisibility(View.GONE);
                                                if(task.isSuccessful()){
                                                    Toast.makeText(SignupActivity.this, "Register Successfully", Toast.LENGTH_SHORT).show();
//                                                    finish();
                                                }else{
                                                    new AlertDialog.Builder(SignupActivity.this).setMessage(task.getException().getMessage()).show();
                                                }
                                            }
                                        });

                                    }


                                    editor.putString("userCat",user.userCat);
                                    editor.commit();
                                    if(user.userCat.equals("patient")){
                                        Intent intent = new Intent(SignupActivity.this,HomePatientActivity.class);
                                        startActivity(intent);
                                    }else if(user.userCat.equals("donor")){
                                        Intent intent = new Intent(SignupActivity.this,HomeDonorActivity.class);
                                        startActivity(intent);
                                    }else if(user.userCat.equals("hospital")){
                                        Intent intent = new Intent(SignupActivity.this,HomeHospitalActivity.class);
                                        startActivity(intent);
                                    }
                                } else {
                                    progressBar.setVisibility(View.GONE);
                                    // If sign in fails, display a message to the user.
                                    new AlertDialog.Builder(SignupActivity.this).setMessage(task.getException().getMessage()).show();
                                }
                            }
                        });
            }
        });
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        if(item.getItemId() == android.R.id.home){
            finish();
        }
        return super.onOptionsItemSelected(item);
    }
}