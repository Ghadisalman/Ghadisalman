package com.project.ehyaa;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.preference.PreferenceManager;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.RadioButton;

import com.creageek.segmentedbutton.SegmentedButton;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;
//[4:20 pm, 15/05/2022] +966 53 823 7585: حساب الدونور
//        donors@gmail.com
//123123
//        حساب المستشفى
//        hospital.sara@gmail.com
//123123
//        [4:20 pm, 15/05/2022] +966 53 823 7585: حساب بيشنت
//        patient@gmail.com
//123123

public class RequstsFragment extends Fragment {

    RequestAdapter adapter;
    ArrayList<Request> requests = new ArrayList<>();
    ArrayList<Request> emergencyRequestsArry = new ArrayList<>();
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View root =  inflater.inflate(R.layout.fragment_requsts, container, false);
        SegmentedButton options = root.findViewById(R.id.options);
        RadioButton emergencyRequests = root.findViewById(R.id.emergencyRequests);
        RadioButton newRequest = root.findViewById(R.id.newRequest);


        RecyclerView recyclerView = root.findViewById(R.id.recyclerView);
        LinearLayoutManager linearLayoutManager = new LinearLayoutManager(getActivity(),RecyclerView.VERTICAL,false);
        recyclerView.setLayoutManager(linearLayoutManager);
         adapter = new RequestAdapter(getActivity(),emergencyRequestsArry);
        recyclerView.setAdapter(adapter);
        SharedPreferences sharedPreferences = PreferenceManager.getDefaultSharedPreferences(getActivity());
        emergencyRequests.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                 adapter = new RequestAdapter(getActivity(),emergencyRequestsArry);
                recyclerView.setAdapter(adapter);
            }
        });

        newRequest.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                adapter = new RequestAdapter(getActivity(),requests);
                recyclerView.setAdapter(adapter);
            }
        });
        String userCat =  sharedPreferences.getString("userCat","");

        if(userCat.equals("patient")){
            options.setVisibility(View.GONE);
            FirebaseDatabase.getInstance().getReference("Requests").orderByChild("patientId").equalTo(FirebaseAuth.getInstance().getCurrentUser().getUid()).addValueEventListener(new ValueEventListener() {
                @Override
                public void onDataChange(@NonNull DataSnapshot snapshot) {
                    requests.clear();
                    for (DataSnapshot dataSnapshot : snapshot.getChildren()){
                        Request request = dataSnapshot.getValue(Request.class);
                        requests.add(request);
                    }
                    adapter.notifyDataSetChanged();
                }

                @Override
                public void onCancelled(@NonNull DatabaseError error) {

                }
            });
        }else if(userCat.equals("donor")){
            options.setVisibility(View.VISIBLE);
            FirebaseDatabase.getInstance().getReference("Requests").orderByChild("accepted").equalTo(true).addValueEventListener(new ValueEventListener() {
                @Override
                public void onDataChange(@NonNull DataSnapshot snapshot) {
                    requests.clear();
                    for (DataSnapshot dataSnapshot : snapshot.getChildren()){
                        Request request = dataSnapshot.getValue(Request.class);
                        if(request.getHospitalId().equals(request.getPatientId())){
                            emergencyRequestsArry.add(request);
                        }else {
                            requests.add(request);
                        }
                    }
                    adapter.notifyDataSetChanged();
                }

                @Override
                public void onCancelled(@NonNull DatabaseError error) {

                }
            });
        }else if(userCat.equals("hospital")){
            options.setVisibility(View.GONE);
            FirebaseDatabase.getInstance().getReference("Requests").orderByChild("hospitalId").equalTo(FirebaseAuth.getInstance().getCurrentUser().getUid()).addValueEventListener(new ValueEventListener() {
                @Override
                public void onDataChange(@NonNull DataSnapshot snapshot) {
                    requests.clear();
                    for (DataSnapshot dataSnapshot : snapshot.getChildren()){
                        Request request = dataSnapshot.getValue(Request.class);
                        if(!request.isAccepted()){
//                            if(request.getHospitalId().equals(request.getPatientId())){

//                                emergencyRequestsArry.add(request);
//                            }else {
                                requests.add(request);
//                            }
                        }

                    }
                    adapter = new RequestAdapter(getActivity(),requests);
                    recyclerView.setAdapter(adapter);
                }

                @Override
                public void onCancelled(@NonNull DatabaseError error) {

                }
            });
        }



        return root;
    }
}