    package com.project.ehyaa;

import android.content.Intent;
import android.content.SharedPreferences;
import android.net.Uri;
import android.os.Bundle;
import android.preference.PreferenceManager;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import com.bumptech.glide.Glide;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageReference;

import java.util.HashMap;
import java.util.Map;

public class ShowRequestDetailsActivity extends AppCompatActivity {

    private TextView fileNumber;
    private TextView requestType;
    private TextView city;
    private ImageView image;
    private TextView nationality;
    private TextView name;
    private Button accept;
    private Button reject;
    private Button chat;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_show_request_details);
        getSupportActionBar().setTitle("Details");
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        Intent intent = getIntent();
        Request request = (Request) intent.getSerializableExtra("request");


        name = findViewById(R.id.name);
        fileNumber = findViewById(R.id.fileNumber);
        requestType = findViewById(R.id.requestType);
        image = findViewById(R.id.image);
        city = findViewById(R.id.city);
        nationality = findViewById(R.id.nationality);
        fileNumber.setText(request.getFileNumber());
        requestType.setText(request.getRequestType());
        city.setText(request.getCity());
        nationality.setText(request.getNationality());


        FirebaseDatabase.getInstance().getReference("users").child(request.getPatientId()).get().addOnCompleteListener(new OnCompleteListener<DataSnapshot>() {
            @Override
            public void onComplete(@NonNull Task<DataSnapshot> task) {
                if(task.isSuccessful()){
                    User user = task.getResult().getValue(User.class);
                    name.setText(user.fullname);

                    StorageReference storageRef = FirebaseStorage.getInstance().getReference().child("UsersImages").child(request.getPatientId()+".jpeg");
                    storageRef.getDownloadUrl().addOnSuccessListener(new OnSuccessListener<Uri>() {
                        @Override
                        public void onSuccess(Uri uri) {
                            // Got the download URL for 'users/me/profile.png'
                            Glide.with(ShowRequestDetailsActivity.this)
                                    .load(uri)
                                    .placeholder(R.drawable.u)
                                    .into(image);
                        }
                    }).addOnFailureListener(new OnFailureListener() {
                        @Override
                        public void onFailure(@NonNull Exception exception) {
                            // Handle any errors
                        }
                    });
                }
            }
        });

        accept = findViewById(R.id.accept);
        reject = findViewById(R.id.reject);
        chat = findViewById(R.id.chat);


        if(request.getPatientId().equals(FirebaseAuth.getInstance().getCurrentUser().getUid())){
            accept.setVisibility(View.GONE);
            reject.setVisibility(View.GONE);
        }
        SharedPreferences sharedPreferences = PreferenceManager.getDefaultSharedPreferences(this);
        String userCat =  sharedPreferences.getString("userCat","");

        if(userCat.equals("donor")){
            accept.setVisibility(View.GONE);
            reject.setVisibility(View.GONE);
        }

        accept.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Map map = new HashMap();
                map.put("accepted",true);
                FirebaseDatabase.getInstance().getReference("Requests").child(request.getId()).updateChildren(map).addOnCompleteListener(new OnCompleteListener() {
                    @Override
                    public void onComplete(@NonNull Task task) {
                        if(task.isSuccessful()){
                            Notification notification = new Notification();
                            String id = FirebaseDatabase.getInstance().getReference("Notifications").push().getKey();
                            notification.setId(id);
                            notification.setTitle("Your request has been accepted");
                            notification.setDetails("Your request with file number "+ request.getFileNumber() + " has been accepted");
                            notification.setUserId(request.getPatientId());
                            FirebaseDatabase.getInstance().getReference("Notifications").child(id).setValue(notification).addOnCompleteListener(new OnCompleteListener<Void>() {
                                @Override
                                public void onComplete(@NonNull Task<Void> task) {
                                    if(task.isSuccessful()){
                                        Toast.makeText(ShowRequestDetailsActivity.this, "Request Accepted Successfully", Toast.LENGTH_SHORT).show();
                                        finish();
                                    }else{
                                        Toast.makeText(ShowRequestDetailsActivity.this, ""+task.getException().getMessage(), Toast.LENGTH_SHORT).show();
                                    }
                                }
                            });

                        }else{
                            Toast.makeText(ShowRequestDetailsActivity.this, ""+task.getException().getMessage(), Toast.LENGTH_SHORT).show();
                        }
                    }
                });
            }
        });



        reject.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
//                Map map = new HashMap();
//                map.put("accepted",false);
                FirebaseDatabase.getInstance().getReference("Requests").child(request.getId()).removeValue().addOnCompleteListener(new OnCompleteListener<Void>() {
                    @Override
                    public void onComplete(@NonNull Task<Void> task) {
                        if(task.isSuccessful()){
                            Toast.makeText(ShowRequestDetailsActivity.this, "Request Rejected Successfully", Toast.LENGTH_SHORT).show();
                        }else{
                            Toast.makeText(ShowRequestDetailsActivity.this, ""+task.getException().getMessage(), Toast.LENGTH_SHORT).show();
                        }
                    }
                });
//                FirebaseDatabase.getInstance().getReference("Requests").child(request.getId()).updateChildren(map).addOnCompleteListener(new OnCompleteListener() {
//                    @Override
//                    public void onComplete(@NonNull Task task) {
//
//                    }
//                });
            }
        });

        chat.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
//                FirebaseDatabase.getInstance().getReference("conversations").get().addOnCompleteListener(new OnCompleteListener<DataSnapshot>() {
//                    @Override
//                    public void onComplete(@NonNull Task<DataSnapshot> task) {
//                        if(task.isSuccessful()){
//                            
//                        }
//                    }
//                });
                
                Conversation conversation = new Conversation();
                String id = FirebaseDatabase.getInstance().getReference("conversations").push().getKey();
                conversation.setId(id);
                conversation.setPatientId(request.getPatientId());
                conversation.setDonorId(FirebaseAuth.getInstance().getCurrentUser().getUid());
                conversation.setTitle(request.getFileNumber());
                conversation.setDetails(request.getRequestType()+" - "+ request.getCity() );


                FirebaseDatabase.getInstance().getReference("conversations").get().addOnCompleteListener(new OnCompleteListener<DataSnapshot>() {
                    @Override
                    public void onComplete(@NonNull Task<DataSnapshot> task) {
                        if(task.isSuccessful()){

                            Conversation forConversation = null;
                            for (DataSnapshot dataSnapshot :task.getResult().getChildren()){
                                 forConversation = dataSnapshot.getValue(Conversation.class);
                                if(forConversation.getDonorId().equals(conversation.getDonorId()) && forConversation.getPatientId().equals(conversation.getPatientId())){
                                    Intent intent1 = new Intent(ShowRequestDetailsActivity.this,ChatActivity.class);
                                intent1.putExtra("conversation",forConversation);
                                startActivity(intent1);
                                }
                            }
                            if(forConversation == null) {
                                FirebaseDatabase.getInstance().getReference("conversations").child(id).setValue(conversation).addOnCompleteListener(new OnCompleteListener<Void>() {
                                    @Override
                                    public void onComplete(@NonNull Task<Void> task) {
                                        if (task.isSuccessful()) {
                                            Intent intent1 = new Intent(ShowRequestDetailsActivity.this, ChatActivity.class);
                                            intent1.putExtra("conversation", conversation);
                                            startActivity(intent1);
                                        } else {

                                        }
                                    }
                                });
                            }
//                            }else{
//                                Intent intent1 = new Intent(ShowRequestDetailsActivity.this,ChatActivity.class);
//                                intent1.putExtra("conversation",conversation);
//                                startActivity(intent1);
//                            }
                        }
                    }
                });
            }
        });
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        if(item.getItemId() == android.R.id.home){
            finish();
        }
        return super.onOptionsItemSelected(item);
    }
}