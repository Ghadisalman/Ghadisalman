package com.project.ehyaa;



public class User {

    public String id;
    public String userCat;
    public String fullname;
    public String hospitalName;
    public String city;
    public String email;
    public String phone;
    public String national;
    public String DateofBirth;
    public String bloodType;
    public User() {

    }

    public User(String id, String userCat, String fullname, String email, String phone, String national, String dateofBirth, String bloodType) {
        this.id = id;
        this.userCat = userCat;
        this.fullname = fullname;
        this.email = email;
        this.phone = phone;
        this.national = national;
        DateofBirth = dateofBirth;
        this.bloodType = bloodType;
    }

    public User(String id, String userCat, String hospitalName, String city, String email, String phone) {
        this.id = id;
        this.userCat = userCat;
        this.hospitalName = hospitalName;
        this.city = city;
        this.email = email;
        this.phone = phone;
    }

    @Override
    public String toString() {
        return  hospitalName;
    }
}
