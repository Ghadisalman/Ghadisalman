package com.project.ehyaa;

import android.content.SharedPreferences;
import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;

import android.preference.PreferenceManager;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;
import java.util.List;

/**
 * A simple {@link Fragment} subclass.
 * Use the {@link AddRequestFragment#newInstance} factory method to
 * create an instance of this fragment.
 */
public class AddRequestFragment extends Fragment {


    ArrayList<User> users = new ArrayList<>();
    // TODO: Rename parameter arguments, choose names that match
    // the fragment initialization parameters, e.g. ARG_ITEM_NUMBER
    private static final String ARG_PARAM1 = "param1";
    private static final String ARG_PARAM2 = "param2";

    // TODO: Rename and change types of parameters
    private String mParam1;
    private String mParam2;

    public AddRequestFragment() {
        // Required empty public constructor
    }

    /**
     * Use this factory method to create a new instance of
     * this fragment using the provided parameters.
     *
     * @param param1 Parameter 1.
     * @param param2 Parameter 2.
     * @return A new instance of fragment AddRequestFragment.
     */
    // TODO: Rename and change types and number of parameters
    public static AddRequestFragment newInstance(String param1, String param2) {
        AddRequestFragment fragment = new AddRequestFragment();
        Bundle args = new Bundle();
        args.putString(ARG_PARAM1, param1);
        args.putString(ARG_PARAM2, param2);
        fragment.setArguments(args);
        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (getArguments() != null) {
            mParam1 = getArguments().getString(ARG_PARAM1);
            mParam2 = getArguments().getString(ARG_PARAM2);
        }
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view = inflater.inflate(R.layout.fragment_add_request, container, false);

        Spinner requestType = view.findViewById(R.id.requestType);
        Spinner hospitals = view.findViewById(R.id.hospitals);
        Spinner bloodType = view.findViewById(R.id.bloodType);
        Spinner city = view.findViewById(R.id.city);
        EditText fileNumber = view.findViewById(R.id.fileNumber);
        EditText nationality = view.findViewById(R.id.nationality);
        Button add = view.findViewById(R.id.add);

        SharedPreferences sharedPreferences = PreferenceManager.getDefaultSharedPreferences(getActivity());

        String userCat =  sharedPreferences.getString("userCat","");

        if(userCat.equals("hospital")){
            hospitals.setVisibility(View.GONE);
            nationality.setHint("Patient Name");
        }

        ArrayAdapter<User> arrayAdapter = new ArrayAdapter<User>(getActivity(), android.R.layout.simple_spinner_dropdown_item,users);

        hospitals.setAdapter(arrayAdapter);


        requestType.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                if(requestType.getSelectedItem().equals("Blood")){
                    bloodType.setVisibility(View.VISIBLE);
                }else{
                    bloodType.setVisibility(View.GONE);
                }
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });

        FirebaseDatabase.getInstance().getReference("users").orderByChild("userCat").equalTo("hospital").addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                for (DataSnapshot data : snapshot.getChildren()){
                    User user = data.getValue(User.class);
                    users.add(user);
                }
                arrayAdapter.notifyDataSetChanged();
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {

            }
        });


        add.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String key = FirebaseDatabase.getInstance().getReference("Requests").push().getKey();
                Request request = new Request();
                request.setId(key);
                if(userCat.equals("hospital")){
                    request.setHospitalId(FirebaseAuth.getInstance().getCurrentUser().getUid());
                    request.setAccepted(true);
                }else{
                    User hospital = (User) hospitals.getSelectedItem();
                    request.setHospitalId(hospital.id);
                }
                request.setCity(city.getSelectedItem().toString());
                request.setRequestType(requestType.getSelectedItem().toString());
                request.setPatientId(FirebaseAuth.getInstance().getCurrentUser().getUid());
                request.setFileNumber(fileNumber.getText().toString());
                request.setNationality(nationality.getText().toString());
                request.setBloodType(bloodType.getSelectedItem().toString().equals("Select Blood Type")?"":bloodType.getSelectedItem().toString());

                FirebaseDatabase.getInstance().getReference("Requests").child(key).setValue(request).addOnCompleteListener(new OnCompleteListener<Void>() {
                    @Override
                    public void onComplete(@NonNull Task<Void> task) {
                        if(task.isSuccessful()){
                            Notification notification = new Notification();
                            String id = FirebaseDatabase.getInstance().getReference("Notifications").push().getKey();
                            notification.setId(id);
                            notification.setTitle("New request added");
                            notification.setDetails("Your can review request with file number "+ request.getFileNumber() + " to accepted or rejected");
                            notification.setUserId(request.getHospitalId());
                            FirebaseDatabase.getInstance().getReference("Notifications").child(id).setValue(notification).addOnCompleteListener(new OnCompleteListener<Void>() {
                                @Override
                                public void onComplete(@NonNull Task<Void> task) {
                                    if(task.isSuccessful()){
                                        Toast.makeText(getActivity(), "Request Added Successfully", Toast.LENGTH_SHORT).show();

                                    }else{
                                        Toast.makeText(getActivity(), ""+task.getException().getMessage(), Toast.LENGTH_SHORT).show();
                                    }
                                }
                            });
                        }else{
                            Toast.makeText(getActivity(), ""+task.getException().getMessage(), Toast.LENGTH_SHORT).show();
                        }
                    }
                });

            }
        });

        return view;
    }
}