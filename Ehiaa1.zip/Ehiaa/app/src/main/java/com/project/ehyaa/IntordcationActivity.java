package com.project.ehyaa;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.content.SharedPreferences;
import android.content.res.Configuration;
import android.media.audiofx.DynamicsProcessing;
import android.os.Bundle;
import android.preference.PreferenceManager;
import android.view.View;
import android.widget.Button;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;

import java.util.Locale;

public class IntordcationActivity extends AppCompatActivity {

    private FirebaseAuth mAuth;

    @Override
    public void onStart() {
        super.onStart();
        SharedPreferences sharedPreferences = PreferenceManager.getDefaultSharedPreferences(this);


//         ...
// Initialize Firebase Auth
        mAuth = FirebaseAuth.getInstance();
        // Check if user is signed in (non-null) and update UI accordingly.
        FirebaseUser currentUser = mAuth.getCurrentUser();
        if(currentUser != null){
            String userCat =  sharedPreferences.getString("userCat","");
            if(userCat.equals("patient")){
                Intent intent = new Intent(IntordcationActivity.this,HomePatientActivity.class);
                startActivity(intent);
                finish();
            }else if(userCat.equals("donor")){
                Intent intent = new Intent(IntordcationActivity.this,HomeDonorActivity.class);
                startActivity(intent);
                finish();
            }else if(userCat.equals("hospital")){
                Intent intent = new Intent(IntordcationActivity.this,HomeHospitalActivity.class);
                startActivity(intent);
                finish();
            }

        }
    }


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_intordcation);
        getSupportActionBar().hide();
        Button signin = findViewById(R.id.signin);
        signin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(getApplicationContext(), SigninActivity.class);
                startActivity(intent);
            }
        });
        Configuration config = new Configuration();
        config.locale = new Locale("en");

        getResources().updateConfiguration(config,getResources().getDisplayMetrics());

        Button signup = findViewById(R.id.signup);
        signup.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(getApplicationContext(), SignupActivity.class);
                startActivity(intent);
            }
        });
    }
}