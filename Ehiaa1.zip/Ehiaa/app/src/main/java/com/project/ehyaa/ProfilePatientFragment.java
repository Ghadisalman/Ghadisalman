package com.project.ehyaa;

import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Bitmap;
import android.graphics.drawable.BitmapDrawable;
import android.net.Uri;
import android.os.Bundle;
import android.preference.PreferenceManager;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import com.bumptech.glide.Glide;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageReference;
import com.google.firebase.storage.UploadTask;

import java.io.ByteArrayOutputStream;

import static android.app.Activity.RESULT_OK;


public class ProfilePatientFragment extends Fragment {


    private ImageView updateImage;
    private EditText fullname;
    private EditText email;
    private EditText phone;
    private EditText national;
    private EditText DateofBirth;
    private EditText bloodType;
    private EditText hospital_name;
    private EditText city;
    private Button Update;
    Uri uri;
    User user;
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setHasOptionsMenu(true);
    }
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view = inflater.inflate(R.layout.fragment_profile_patient, container, false);
        updateImage = view.findViewById(R.id.updateImage);
        fullname = view.findViewById(R.id.fullname);
        city = view.findViewById(R.id.city);
        hospital_name = view.findViewById(R.id.hospital_name);
        email = view.findViewById(R.id.email);
        email.setEnabled(false);

        phone = view.findViewById(R.id.phone);
        national = view.findViewById(R.id.national);
        DateofBirth = view.findViewById(R.id.DateofBirth);
        bloodType = view.findViewById(R.id.bloodType);
        bloodType.setEnabled(false);
        Update = view.findViewById(R.id.Update);

        SharedPreferences sharedPreferences = PreferenceManager.getDefaultSharedPreferences(getActivity());
        String userCat =  sharedPreferences.getString("userCat","");
        if (userCat.equals("patient")){
            fullname.setVisibility(View.VISIBLE);
            hospital_name.setVisibility(View.GONE);
            city.setVisibility(View.GONE);
            email.setVisibility(View.VISIBLE);
            phone.setVisibility(View.VISIBLE);
            national.setVisibility(View.VISIBLE);
            DateofBirth.setVisibility(View.VISIBLE);
            bloodType.setVisibility(View.VISIBLE);
        }else if (userCat.equals("hospital")){
            hospital_name.setVisibility(View.VISIBLE);
            city.setVisibility(View.VISIBLE);
            email.setVisibility(View.VISIBLE);
            phone.setVisibility(View.VISIBLE);
            fullname.setVisibility(View.GONE);
            national.setVisibility(View.GONE);
            DateofBirth.setVisibility(View.GONE);
            bloodType.setVisibility(View.GONE);
        }else if (userCat.equals("donor")){
            fullname.setVisibility(View.VISIBLE);
            hospital_name.setVisibility(View.GONE);
            city.setVisibility(View.GONE);
            email.setVisibility(View.VISIBLE);
            phone.setVisibility(View.VISIBLE);
            national.setVisibility(View.VISIBLE);
            DateofBirth.setVisibility(View.VISIBLE);
            bloodType.setVisibility(View.VISIBLE);
        }



        FirebaseDatabase.getInstance().getReference("users").child(FirebaseAuth.getInstance().getCurrentUser().getUid()).get().addOnCompleteListener(new OnCompleteListener<DataSnapshot>() {
            @Override
            public void onComplete(@NonNull Task<DataSnapshot> task) {
                if(task.isSuccessful()){
                    user = task.getResult().getValue(User.class);
                    fullname.setText(user.fullname);
                    email.setText(user.email+"");
                    phone.setText(user.phone+"");
                    national.setText(user.national+"");
                    DateofBirth.setText(user.DateofBirth+"");
                    bloodType.setText(user.bloodType+"");
                    city.setText(user.city+"");
                    hospital_name.setText(user.hospitalName+"");
                    StorageReference storageRef = FirebaseStorage.getInstance().getReference().child("UsersImages").child(user.id+".jpeg");
                    storageRef.getDownloadUrl().addOnSuccessListener(new OnSuccessListener<Uri>() {
                        @Override
                        public void onSuccess(Uri uri) {
                            // Got the download URL for 'users/me/profile.png'
                            Glide.with(getContext())
                                    .load(uri)
                                    .into(updateImage);
                        }
                    }).addOnFailureListener(new OnFailureListener() {
                        @Override
                        public void onFailure(@NonNull Exception exception) {
                            // Handle any errors
                        }
                    });
                }else{
                    Toast.makeText(getActivity(), ""+task.getException().getMessage(), Toast.LENGTH_SHORT).show();
                }
            }
        });

        updateImage.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(Intent.ACTION_PICK);
                intent.setType("image/*");
                startActivityForResult(intent,1);
            }
        });
        Update.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                updateImage.setDrawingCacheEnabled(true);
                updateImage.buildDrawingCache();
                Bitmap bitmap = ((BitmapDrawable) updateImage.getDrawable()).getBitmap();
                ByteArrayOutputStream baos = new ByteArrayOutputStream();
                bitmap.compress(Bitmap.CompressFormat.JPEG, 100, baos);
                byte[] data = baos.toByteArray();
                StorageReference storageRef = FirebaseStorage.getInstance().getReference().child("UsersImages").child(FirebaseAuth.getInstance().getCurrentUser().getUid()+".jpeg");
                UploadTask uploadTask = storageRef.putBytes(data);
                uploadTask.addOnFailureListener(new OnFailureListener() {
                    @Override
                    public void onFailure(@NonNull Exception exception) {
                        // Handle unsuccessful uploads
                    }
                }).addOnSuccessListener(new OnSuccessListener<UploadTask.TaskSnapshot>() {
                    @Override
                    public void onSuccess(UploadTask.TaskSnapshot taskSnapshot) {
                        user.fullname = fullname.getText().toString();
                        user.phone = phone.getText().toString();

                        user.national = national.getText().toString();
                        user.DateofBirth = DateofBirth.getText().toString();
                        DateofBirth.setText(user.DateofBirth+"");


                        FirebaseDatabase.getInstance().getReference("users").child(FirebaseAuth.getInstance().getCurrentUser().getUid()).setValue(user).addOnCompleteListener(new OnCompleteListener<Void>() {
                            @Override
                            public void onComplete(@NonNull Task<Void> task) {
                                if(task.isSuccessful()){
                                    Toast.makeText(getActivity(), "Update Profile Successfully", Toast.LENGTH_SHORT).show();
                                }else{
                                    Toast.makeText(getActivity(), ""+task.getException().getMessage(), Toast.LENGTH_SHORT).show();
                                }
                            }
                        });
                    }
                });
            }
        });
        return view;

    }

    @Override
    public void onCreateOptionsMenu(@NonNull Menu menu, @NonNull MenuInflater inflater) {
        super.onCreateOptionsMenu(menu, inflater);

        getActivity().getMenuInflater().inflate(R.menu.logout_menu,menu);
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
if(item.getItemId() == R.id.logout){
    new AlertDialog.Builder(getActivity()).setMessage("Do you want to logout?").setPositiveButton("Yes", new DialogInterface.OnClickListener() {
        @Override
        public void onClick(DialogInterface dialog, int which) {
            FirebaseAuth.getInstance().signOut();
            Intent intent = new Intent(getActivity(),IntordcationActivity.class);
            PreferenceManager.getDefaultSharedPreferences(getActivity()).edit().clear().commit();
            startActivity(intent);
            getActivity().finish();
        }
    }).setNegativeButton("No", new DialogInterface.OnClickListener() {
        @Override
        public void onClick(DialogInterface dialog, int which) {
            dialog.dismiss();
        }
    }).show();
}
        return super.onOptionsItemSelected(item);
    }

    @Override
    public void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if(requestCode == 1 && resultCode == RESULT_OK){
            uri = data.getData();
            updateImage.setImageURI(uri);
        }
    }
}